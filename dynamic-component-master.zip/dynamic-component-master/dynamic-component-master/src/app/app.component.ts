import { Component,ViewChild } from '@angular/core';
import { ComponentCommunicationService } from './service/communication.service';
import{ChildMessage,ChildMessageType} from '../app/model/childmessage.model'
import { Subscription } from 'rxjs';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  public steps: any[] = [];
  public routerOutletSubscription:Subscription;
  
  @ViewChild('stepperProgressbar', { static: false }) stepperProgressbar;
  constructor(protected communicationservice:ComponentCommunicationService) {
    this.steps = ['RCA',
      'GARANZIE',
      'SCONTO',
      'RIEPILOGO',
      'CONTATTI'],
      this.routerOutletSubscription = this.communicationservice.getData().subscribe(data => {            
        this.processMessage(data);
    });
      
  }

  ngOnInit() {
  }
  public processMessage(childMessage: ChildMessage) {
    debugger;
    if(childMessage.Type==ChildMessageType.moveforward){
      this.movenextstep();
    }else if(childMessage.Type==ChildMessageType.movebackword)
      {
        this.moveprevstep();
      }
  }
 public  movenextstep(){
   
    this.stepperProgressbar.moveNext();
  }
  public moveprevstep(){
    this.stepperProgressbar.movePrev();
  }
  onStateChange(event) {
    console.log(event);
  }
}
