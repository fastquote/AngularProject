import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ProfileHostDirective } from './profile/profile-host.directive';
import { ProfileComponent } from './profile/profile.component';
import {ProgressBarComponent}from './progressbar/progressbar.componet';
import {ComponentCommunicationService} from './service/communication.service';

@NgModule({
  declarations: [AppComponent, ProfileHostDirective, ProfileComponent,ProgressBarComponent],
  imports: [BrowserModule],
  providers: [ComponentCommunicationService],
  bootstrap: [AppComponent]})
export class AppModule {}