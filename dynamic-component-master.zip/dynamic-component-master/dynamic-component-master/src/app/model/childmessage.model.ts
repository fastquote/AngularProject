export class ChildMessage{
    constructor(public Type: ChildMessageType, public Message: any) {
    }

}
export const enum ChildMessageType {
    moveforward,
    movebackword
}