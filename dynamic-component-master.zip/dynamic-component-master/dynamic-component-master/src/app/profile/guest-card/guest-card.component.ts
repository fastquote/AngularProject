import { Component } from '@angular/core';
import { ComponentCommunicationService } from 'src/app/service/communication.service';
import { ProfileService } from '../profile.service';
import {ChildMessageType} from '../../model/childmessage.model'

@Component({
  selector: 'app-guest-card',
  templateUrl: './guest-card.component.html',
  styleUrls: ['./guest-card.component.css']
})
export class GuestCardComponent {
  
  constructor(private profileService: ProfileService, private communicationService:ComponentCommunicationService) {}

  login() {
    debugger;
    this.profileService.login();
    this.communicationService.sendData(ChildMessageType.moveforward,true)
  }
 
}
