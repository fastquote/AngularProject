import { Component } from '@angular/core';
import { ComponentCommunicationService } from 'src/app/service/communication.service';
import { ProfileService } from '../profile.service';
import{ChildMessageType,ChildMessage} from '../../model/childmessage.model'

@Component({
  selector: 'app-user-card',
  templateUrl: './user-card.component.html',
  styleUrls: ['./user-card.component.css']
})
export class UserCardComponent {
  constructor(private profileService: ProfileService,private communicationService:ComponentCommunicationService) {}

  logout() {
    debugger;
    this.profileService.logout();
    this.communicationService.sendData(ChildMessageType.moveforward, true)
    
  }
  previous(){
    this.communicationService.sendData(ChildMessageType.movebackword, true)
  }
}