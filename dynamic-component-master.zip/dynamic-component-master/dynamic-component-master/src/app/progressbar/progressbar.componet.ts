import { Component, OnInit, Input, Output, EventEmitter, ContentChildren, QueryList, AfterViewInit } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { stepperbar } from './uihelper';

@Component({
  selector: 'app-progress-bar',
  template: `
<div class="formStepperbar">
  <ul>
    <li *ngFor="let item of progressbarsteps" [class.active]="currentPage==item" >
      <span>{{item}}</span></li>
  </ul>
  
</div>
`,
})
export class ProgressBarComponent extends stepperbar implements OnInit, AfterViewInit {
  @Input() progressbarsteps: any[];
  public stepelement = document.querySelectorAll('div ul li');
  @Output() public stateChange = new EventEmitter<{
    activeIndex: number;
  }>();
  public currentPage: string;
  public currentPageIndex: number;
  constructor() {
    super();
  }

  ngOnInit() {
    this.currentPageIndex = this.activeIndex;
    console.log(this.progressbarsteps);
    if (!isNullOrUndefined(this.progressbarsteps) && this.progressbarsteps.length > 0) {
      this.currentPage = this.progressbarsteps[this.activeIndex];
    }
  }

  ngAfterViewInit() {
    this.stepelement = document.querySelectorAll('div ul li')
  }


  public moveNext() {
    if (!isNullOrUndefined(this.progressbarsteps) && this.activeIndex < this.progressbarsteps.length - 1) {
      this.currentPageIndex = this.activeIndex + 1;
      this.currentPage = this.progressbarsteps[this.currentPageIndex];
      this.movenextStep(this.currentPageIndex, this.stepelement);
      this.activeIndex = this.currentPageIndex;
      this.stateChange.emit({
        activeIndex: this.activeIndex,

      });
    }
  }

  public movePrev() {
    if (!isNullOrUndefined(this.progressbarsteps) && this.activeIndex > 0) {
      this.currentPageIndex = this.activeIndex - 1;
      this.currentPage = this.progressbarsteps[this.currentPageIndex];
      this.moveprevStep(this.currentPageIndex);
      this.activeIndex = this.currentPageIndex;
      this.stateChange.emit({
        activeIndex: this.activeIndex,

      });
    }
  }
}

