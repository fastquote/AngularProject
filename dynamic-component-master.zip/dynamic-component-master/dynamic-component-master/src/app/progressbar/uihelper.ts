export class stepperbar {
    public activeIndex = 0;
    public stepelement: any
    public successitemlist: any[] = [];



    public movenextStep(index: number, element: any) {
        this.stepelement = element
        this.addsuccessclass(index);
    }
    public moveprevStep(index: number) {
        this.removesuccessclass(index);
    }
    public addActiveClass(index: number) {

    }
    public addsuccessclass(index: number) {
        for (let i = 0; i <= index - 1; i++) {
            this.successitemlist.push(i);
        }

        for (let i = 0; i <= index - 1; i++) {
            this.stepelement[i] && this.stepelement[i].classList.add('success');
        }
        this.successitemlist = [];
    }
    public removesuccessclass(index: number) {
        this.successitemlist.push(index);
        this.stepelement[index] && this.stepelement[index].classList.remove('success');
        this.successitemlist = [];
       
    }

}
