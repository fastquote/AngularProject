import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
//import { Subject } from 'rxjs';
import { ChildMessage } from '../model/childmessage.model';

@Injectable()
export class ComponentCommunicationService {
    private subject = new Subject<ChildMessage>();
    private questionCountSubject = new Subject<number>();
    private questionNumberSubject = new Subject<number>();
    private sessionSubject = new Subject<string>();
    private dataSubject = new Subject<any>();

    private plateNumberSubject = new Subject<string>();
    private dobSubject = new Subject<string>();

    private activitySubject = new Subject<string>();

    sendPlateNumber(plateNumber: string) {
        this.plateNumberSubject.next(plateNumber);
    }

    clearPlateNumber() {
        this.plateNumberSubject.next();
    }

    getPlateNumber(): Observable<string> {
        return this.plateNumberSubject.asObservable();
    }

    sendDob(dob: string) {
        this.dobSubject.next(dob);
    }

    clearDob() {
        this.dobSubject.next();
    }

    getDob(): Observable<string> {
        return this.dobSubject.asObservable();
    }

    sendInfo(data:any) {
        this.dataSubject.next(data);
    }
    clearInfo() {
        this.dataSubject.next();
    }

    getInfo(): Observable<any> {
        return this.dataSubject.asObservable();
    }

    sendSession(sessionId: string) {
        this.sessionSubject.next(sessionId);
    }

    clearSessionData() {
        this.sessionSubject.next();
    }

    getSessionData(): Observable<string> {
        return this.sessionSubject.asObservable();
    }

    sendData(type: number, message: any) {
        this.subject.next(new ChildMessage(type, message));
    }

    clearData() {
        this.subject.next();
    }

    getData(): Observable<ChildMessage> {
        return this.subject.asObservable();
    }
    sendActivityId(message: any) {
        this.activitySubject.next(message);
    }

    clearActivityId() {
        this.activitySubject.next();
    }

    getActivityId(): Observable<string> {
        return this.activitySubject.asObservable();
    }

    sendQuestionCount(count: number) {
        this.questionCountSubject.next(count);
    }

    clearQuestionCount() {
        this.questionCountSubject.next();
    }

    getQuestionCount(): Observable<number> {
        return this.questionCountSubject.asObservable();
    }
    sendQuestionNumber(count: number) {
        this.questionNumberSubject.next(count);
    }

    clearQuestionNumber() {
        this.questionNumberSubject.next();
    }

    getQuestionNumber(): Observable<number> {
        return this.questionNumberSubject.asObservable();
    }    
    
}